﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРОEntities()) 
            {
                User usern = db.User.FirstOrDefault(user => user.Login == log.Text && user.Password == pas.Text);
                if (usern != null)
                {
                    MessageBox.Show("Неверно введен логин или пароль");
                }
                else
                {
                    MessageBox.Show("Вы успешно авторизованы");
                    input input = new input();
                    input.Show();
                }

            }

        }

        private void Registracia_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРОEntities())
            {
                var usern = new User();
                usern.Login = log.Text;
                usern.Password = pas.Text;
                var usern1 = db.User.FirstOrDefault(uch => uch.Login == log.Text);
                if (usern1 != null)
                {
                    db.User.Add(usern);
                    db.SaveChanges();
                    MessageBox.Show("Вы успешно зарегистрировались");
                }

                else
                {
                    MessageBox.Show("Такой логин существует");
                }
            }
        }
    }
}
