﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для PersonRequest.xaml
    /// </summary>
    public partial class PersonRequest : Window
    {
        public PersonRequest()
        {
            InitializeComponent();
        }

        private void Oforml_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРОEntities())
            {
                var visitor = new Visitor();
                visitor.Last_name = last.Text;
                visitor.First_name = first.Text;
                visitor.Middle_name = midle.Text;
                visitor.Phone = phone.Text;
                visitor.Email = email.Text;
                visitor.Organization = org.Text;
                visitor.Note = note.Text;

                visitor.Passport_series = Convert.ToInt32(series.Text);
                visitor.Passport_number = Convert.ToInt32(number.Text);
                
            }

            

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРОEntities())
            {
                Depar.ItemsSource = db.Department.Select(d => d.Title).ToList();
            }

            using (var db = new ХранительПРОEntities())
            {
                purpose.ItemsSource = db.Visit.Select(d => d.Purpose).ToList();
            }
        }
    }
}
